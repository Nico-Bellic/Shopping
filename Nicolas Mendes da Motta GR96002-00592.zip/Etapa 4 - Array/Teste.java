public class Teste {
    public static void main(String[] args) {
        Endereco endereco = new Endereco("Rua A", "Cidade B", "Estado C", "País D", "12345-678", "10", "Apto 1");
        Data dataFundacao = new Data(1, 1, 2000);
        Produto produto1 = new Produto("Produto 1", 10.0, new Data(1, 1, 2025));
        Produto produto2 = new Produto("Produto 2", 20.0, new Data(1, 1, 2026));

        Cosmetico cosmetico = new Cosmetico("Loja de Cosméticos", 10, 1500.0, endereco, dataFundacao, 5.0, 100);
        cosmetico.insereProduto(produto1);
        cosmetico.insereProduto(produto2);

        cosmetico.imprimeProdutos();

        System.out.println(cosmetico);
    }
}
